package entities;

public class ListaLivros<T> {
	private static final int TAMANHO_INICIAL = 10;
	private Livro[] livros;
	private int tamanho;

	public ListaLivros() {
		this.livros = (Livro[]) new Livro[TAMANHO_INICIAL];
		this.tamanho = 0;
	}

	public void adicionar(Livro livro) {
		if (tamanho == livros.length) {
			resize();
		}
		livros[tamanho] = livro;
		tamanho++;
	}

	private void resize() {
		int newTamanho = livros.length * 2;
		Livro[] newArray = (Livro[]) new Livro[newTamanho];
		System.arraycopy(livros, 0, newArray, 0, livros.length);
		livros = newArray;
	}

	public void buscarLivro(String titulo) {
		if (livros[0] == null) {
			System.out.println("lista vazia");
		} else {
			boolean encontrado = false;
			for (int i = 0; i < tamanho; i++) {
				if (livros[i] != null && livros[i].getTitulo().equals(titulo)) {
					System.out.println(livros[i]);
					encontrado = true;
				}
			}
			if (!encontrado) {
				System.out.println("Nenhum livro com este titulo encontrado !!!");
			}
		}
	}

	public void listar() {
		if (livros[0] == null) {
			System.out.println("lista vazia");
		} else {
			for (int i = 0; i < tamanho; i++) {
				if (livros[i] != null) {
					System.out.println(i + " " + livros[i]);
				}
			}
		}
	}

	public void ordenarLivros() {
		Livro temp;
		if (livros[0] == null) {
			System.out.println("lista vazia");
		} else {
			System.out.println("Autores foram ordenados alfabeticamente !!!");
			for (int i = 0; i < tamanho; i++) {
				for (int j = i + 1; j < tamanho; j++) {
					if (livros[j].compareTo(livros[i]) < 0) {
						temp = livros[i];
						livros[i] = livros[j];
						livros[j] = temp;
					}
				}
			}
		}
	}

	public int getSize() {
		return tamanho;
	}

	public int getLength() {
		return livros.length;
	}
}
