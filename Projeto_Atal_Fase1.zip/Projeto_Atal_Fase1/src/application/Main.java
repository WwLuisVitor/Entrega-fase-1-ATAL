package application;

import java.util.InputMismatchException;
import java.util.Scanner;

import entities.ListaLivros;
import entities.Livro;

public class Main {

	public static void main(String[] args) {
		ListaLivros<Livro> listaLivros = new ListaLivros<>();
		Scanner sc = new Scanner(System.in);
		boolean rodando = true;
		while (rodando) {
			showMenu();
			System.out.print("Digite o numero da opcao que voce deseja: ");
			String op = sc.nextLine();
			switch (op) {
			case "1":
				System.out.print("Digite o nome do Autor: ");
				String autor = sc.nextLine();
				System.out.print("Digite o titulo do livro: ");
				String titulo = sc.nextLine();
				int ano = 0;
				boolean anoValido = false;
				while (!anoValido) {
					System.out.print("Digite o ano de publicacao: ");
					try {
						ano = sc.nextInt();
						anoValido = true;
					} catch (InputMismatchException e) {
						System.out.println("Digite um valor valido para o ano!");
						sc.next(); // Limpar o buffer do Scanner
					}
				}
				sc.nextLine(); // Consumir a nova linha restante
				Livro livro = new Livro(autor, titulo, ano);
				listaLivros.adicionar(livro);
				break;
			case "2":
				System.out.println();
				listaLivros.listar();
				break;
			case "3":
				System.out.print("Digite o titulo do livro que voce deseja: ");
				String t = sc.nextLine();
				System.out.println();
				listaLivros.buscarLivro(t);
				break;
			case "4":
				System.out.println();
				listaLivros.ordenarLivros();
				break;
			case "5":
				System.out.println("Fim da aplicacao!");
				rodando = false;
				break;
			default:
				System.out.println("Ops! Esta opcao nao existe, por favor escolha uma de 1 a 5!");
				break;
			}
		}
		sc.close();
	}

	public static void showMenu() {
		System.out.println(".:.:.:.:.:.:.:.:.:..:.:.:.:.:.:.:.:.:.");
		System.out.println();
		System.out.println("1) Adicionar Livro");
		System.out.println("2) Listar Livros");
		System.out.println("3) Buscar Livro");
		System.out.println("4) Ordenar Livros");
		System.out.println("5) Sair");
		System.out.println();
		System.out.println(".:.:.:.:.:.:.:.:.:..:.:.:.:.:.:.:.:.:.");
		System.out.println();
	}
}
